import pygame
import os
os.environ['SDL_VIDEODRIVER']='windib'
pygame.init()

BLACK = (0,   0,   0)# Define some colors
WHITE = (255, 255, 255)
LIGHTBLUE = (133, 214,   255)

WIN_WIDTH = 800 # define dimensions
WIN_HEIGHT = 550
HALF_WIDTH = int(WIN_WIDTH / 2)
HALF_HEIGHT = int(WIN_HEIGHT / 2)
size = (WIN_WIDTH, WIN_HEIGHT) # set window size


class Camera(object):#create camera class
    def __init__(self, camera_func, width, height): #call the camera fucntion and make the sprite a rectangular camera
        self.camera_func = camera_func
        self.state = pygame.Rect(0, 0, width, height)

    def apply(self, target): #so that camera will be able to move
        return target.rect.move(self.state.topleft)

    def update(self, target): #update the rectangular camera to move view of the level
        self.state = self.camera_func(self.state, target.rect)


def complex_camera(camera, target_rect):
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t, _, _ = -l+HALF_WIDTH, -t+HALF_HEIGHT, w, h

    l = min(0, l)                           # stop scrolling at the left edge
    l = max(-(camera.width-WIN_WIDTH), l)   # stop scrolling at the right edge
    t = max(-(camera.height-WIN_HEIGHT), t) # stop scrolling at the bottom
    t = min(0, t)                           # stop scrolling at the top
    return pygame.Rect(l, t, w, h)


class Thing(pygame.sprite.Sprite): # create thing class
    def __init__(self): # sprite to initialize all sprites
        pygame.sprite.Sprite.__init__(self)


class Character(Thing):#create character class
    def __init__(self, x, y):
        Thing.__init__(self)#use Thing class to intialize character sprite as a separate entity
        self.xspeed = 0#set speed to 0
        self.yspeed = 0
        self.onGround = False        #set rectangle character sprite to be spawned from the top left corner of the screen
        self.image = pygame.Surface((25,25))
        self.image.fill(WHITE)
        self.image.convert()
        self.rect = pygame.Rect(x, y, 25, 25)

    def update(self, up, left, right, platforms):
        if up:#only jump if on the ground
            if self.onGround: self.yspeed -= 9

        if left:        #update charcter to move left
            self.xspeed = -8
        if right:        #update character to move right
            self.xspeed = 8
        if not self.onGround:
            self.yspeed += 0.3            #acceleration downwards by gravity if in air
            if self.yspeed > 100: self.yspeed = 100            #maximum falling speed
        if not(left or right):
            self.xspeed = 0

        self.rect.left += self.xspeed        #update character position increment in x direction

        self.collide(self.xspeed, 0, platforms)        #x-axis collisions with platforms

        self.rect.top += self.yspeed        #update character position by increment in y direction

        self.onGround = False;         #when in air

        self.collide(0, self.yspeed, platforms)        #y-axis collisions with platforms

    def collide(self, xspeed, yspeed, platforms):    #define collisions
        for p in platforms: #for each regular platform
            if pygame.sprite.collide_rect(self, p):#when character collides with platform , block character's path:
                if xspeed > 0:                #if moving right,right side of character sprite is equivalent to the left side of the platform
                    self.rect.right = p.rect.left
                if xspeed < 0:                #if moving left,left side of character sprite is equivalent to the right side of the platform
                    self.rect.left = p.rect.right
                if yspeed > 0:                #if falling down, bottom side of character sprite is equivalent to the top side of the platform
                    self.rect.bottom = p.rect.top
                    self.onGround = True
                    self.yspeed = 0
                if yspeed < 0:                #if jumping up,top side of character sprite is equivalent to the bottom side of the platform
                    self.rect.top = p.rect.bottom


class Platform(Thing): # create platform class
    def __init__(self, x, y):
        Thing.__init__(self)        # use Thing class to intialize platform sprite as a separate entity
        self.image = pygame.Surface((25, 25))        # set rectangle sprites to the screen
        self.image.convert()
        self.image.fill(LIGHTBLUE)
        self.rect = pygame.Rect(x, y, 25, 25)

    def update(self): # platforms do not update
        pass


class coinSprite(Platform):#create coin class
    def __init__(self, x, y): #use platform class to intialize coin sprite as apart of the platform entity
        Platform.__init__(self, x, y)
        self.image = pygame.Surface((25, 25))        #set and load image for coinsprite to the screen
        self.image = pygame.image.load("coin.png")
        self.image = self.image.convert()
        self.rect = self.image.get_rect()        #let coinsprite have properties of a rectangle
        self.image.set_colorkey(BLACK)
        self.rect.centerx = x #set x coordinate for center of sprite
        self.rect.centery = y #set x coordinate for center of sprite

    def update(self):
        self.rect.center = pygame.image.load() #update sprite with image


class fireSprite(Platform):#create fire class
    def __init__(self, x, y):
        Platform.__init__(self, x, y) #use platform class to intialize fire sprite as apart of the platform entity
        self.image = pygame.Surface((75,75))        #set and load image for losesprite to the screen
        self.image = pygame.image.load("fireball.png")
        self.image = self.image.convert()
        self.rect = self.image.get_rect()        #let firesprite have properties of a rectangle
        self.image.set_colorkey(BLACK)
        self.rect.centerx = x #set x coordinate for center of sprite
        self.rect.centery = y #set x coordinate for center of sprite

    def update(self):
        self.rect.center = pygame.image.load() #update sprite with image


class winSprite(Platform):#create win class
    def __init__(self, x, y): #use platform class to intialize win sprite as apart of the platform entity
        Platform.__init__(self, x, y)
        self.image = pygame.Surface((25, 25))        #set and load image for winsprite to the screen
        self.image = pygame.image.load("winsprite.png")
        self.image = self.image.convert()
        self.rect = self.image.get_rect()        #let winsprite have properties of a rectangle
        self.image.set_colorkey(BLACK)
        self.rect.centerx = x #set x coordinate for center of sprite
        self.rect.centery = y #set x coordinate for center of sprite

    def update(self):
        self.rect.center = pygame.image.load() #update sprite with image


def gameWorld (level):       # def gameworld function, 'level' parameter being which gameworld file is opened
    global cameraX, cameraY    # set middle of the camera view
    timer = pygame.time.Clock()    # set timer

    up = left = right = False    # set movement variables to false

    bg = pygame.Surface((25,25))    # set up background
    bg.convert()
    bg.fill(BLACK)

    allSprites = pygame.sprite.Group()    # create a sprite group for all of the sprites

    character = Character(25, 25)    # set character into a variable and have it spawn in top left corner of screen

    platforms = []    # create empty list for platforms, coins, fires and wins
    coins = []
    fires = []
    wins = []

    x = y = 0    # set x and y variables to 0

    designlevel = []    # create empty list for design level

    file = open(level,"r")    # read from selected gamefile and add each line to list to create the placement for each block
    world = file.readlines()
    for line in world:
        designlevel.append(line[:-1])

    # build the level
    for row in designlevel:
        for i in row:
            if i == "P": #spawn a platform where ever there is a P in the design list, append to platform list and add to all sprite group
                p = Platform(x, y)
                platforms.append(p)
                allSprites.add(p)
            if i == "C": #spawn a coin where ever there is a C in the design list, append to coins list and add to all sprite group
                c = coinSprite(x, y)
                coins.append(c)
                allSprites.add(c)
            if i == "F": #spawn a fire where ever there is an F in the design list, append to fires list and add to all sprite group
                f = fireSprite(x, y)
                fires.append(f)
                allSprites.add(f)
            x += 25 #move blocks in game level with the camera screen
        y += 25
        x = 0

    total_level_width  = len(designlevel[0])*25    #set game level dimensions
    total_level_height = len(designlevel)*25

    camera = Camera(complex_camera, total_level_width, total_level_height)    #set camera function into a variable

    allSprites.add(character)    #add character sprite to all sprites group

    global score    #set accumulator variables to 0
    score = 0
    totalcoins = 0

    pygame.mixer.init()

    coin = pygame.mixer.Sound("coinsound.wav")
    jump = pygame.mixer.Sound("jumpsound.wav")
    pygame.mixer.music.load("amazinbgmusic.mp3")

    pygame.mixer.music.play(-1,0)    #play background music

    done = False    #--------------main program loop-------------
    while not done:
        for event in pygame.event.get():        #game logic
            if event.type == pygame.QUIT:            #if user clicked close, exit game
                done = True
                pygame.quit()
                quit()

            elif event.type == pygame.KEYDOWN:            #keyboard controls
                if event.key == pygame.K_UP:
                    up = True
                    pygame.mixer.Sound.play(jump)                    #play jumpsound
                if event.key == pygame.K_LEFT:
                    left = True
                if event.key == pygame.K_RIGHT:
                    right = True

            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_UP:
                    up = False
                if event.key == pygame.K_RIGHT:
                    right = False
                if event.key == pygame.K_LEFT:
                    left = False

        for y in range(60):        # draw background
            for x in range(100):
                screen.blit(bg, (x * 25, y * 25))

        for c in coins:        # when character hits coin, collect points
            if pygame.sprite.collide_rect(character, c):
                pygame.mixer.Sound.play(coin)               # play coin sound effect
                c.rect.centerx = -10                # teleport coin off screen
                c.rect.centery = -10

                score += 4                # increment score by 4 for each coin collected

                print(score)
                totalcoins += 1
                if totalcoins == 25:                # when all coins are collected, crown appears
                    w = winSprite(2450, 250)
                    wins.append(w)
                    allSprites.add(w)

        for f in fires:        # when character hits a fire, user loses game
            if pygame.sprite.collide_rect(character,f):
                lose()

        for w in wins:         # when character hits crown, user wins game
            if pygame.sprite.collide_rect(character,w):
                win()                # call win screen

        camera.update(character)        # call and update camera

        character.update(up, left, right, platforms)        # call and update character

        for e in allSprites:        # draw all sprites and platforms
            screen.blit(e.image, camera.apply(e))

        pygame.display.update()        # update screen

        timer.tick(60)        # update screen every 60 seconds


def lose():# if user collides with fire sprite, lose screen is called
    losescreen=pygame.image.load("lose.jpg").convert()    # load all images
    button1=pygame.image.load("playagainbutton.png").convert()
    button1.set_colorkey(WHITE)
    button2=pygame.image.load("playagainbutton2.png").convert()
    button2.set_colorkey(WHITE)
    scoreimage=pygame.image.load("score"+str(score)+".jpg").convert()    # load score image
    scoreimage.set_colorkey(WHITE)

    pygame.mixer.init()    # load sound effect
    pygame.mixer.music.load("losesound.wav")
    playagain = pygame.mixer.Sound("instructsound.wav")

    pygame.mixer.music.play(0)    # play lose sound effect

    done = False    # -----------------lose screen loop------------------------------

    while not done:
        for event in pygame.event.get():        # allows user to close window and shut down game
            if event.type == pygame.QUIT:
                done = True
                pygame.quit()
                quit()

        screen.blit(losescreen, [0,0])        # pastes background and button and score
        screen.blit(button1, [300, 400])
        screen.blit(scoreimage,[300, 250])
        mouse=pygame.mouse.get_pos()        # gets mouse coordiantes
        mousex=mouse[0]
        mousey=mouse[1]

        if (300<mousex<500) and (400<mousey<500):        # if user moves over button, highlight it, if user clickes button load the level select screen

            screen.blit(button2, [300, 400])
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pygame.mixer.Sound.play(playagain)                    # play sound effect for playing again
                    done == True
                    gameWorld("designlevel.txt")

        pygame.display.flip()


def win():
    # win screen, if user wins game
    winscreen=pygame.image.load("win.jpg").convert()    #load all images
    button1=pygame.image.load("playagainbutton.png").convert()
    button1.set_colorkey(WHITE)
    button2=pygame.image.load("playagainbutton2.png").convert()
    button2.set_colorkey(WHITE)
    screen.blit(button1, [300, 400])
    screen.blit(winscreen, [0,0])

    scoreimage=pygame.image.load("score"+str(score)+".jpg").convert()    #score imag
    scoreimage.set_colorkey(WHITE)

    pygame.mixer.init()    #load sound effects
    pygame.mixer.music.load("winsound.mp3")
    playagain = pygame.mixer.Sound("instructsound.wav")

    pygame.mixer.music.play(0)    #play win sound effect

    done=False    # -----------------win screen loop------------------------------
    while not done:
        for event in pygame.event.get():        # allows user to close window and shut down game
            if event.type == pygame.QUIT:
                done = True
                pygame.quit()
                quit()

        mouse = pygame.mouse.get_pos()        # gets mouse coordinate
        mousex = mouse[0]
        mousey = mouse[1]
        screen.blit(button1, [100,400])        # pastes button and score to screen
        screen.blit(scoreimage, [300, 400])

        if (100<mousex<300) and (400<mousey<500):        # if user moves over button, highlight it, if user clickes button load the level select screen
            screen.blit(button2, [100, 400])
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pygame.mixer.Sound.play(playagain)                    # play sound effect for playing again
                    done==True
                    gameWorld("designlevel.txt")
        pygame.display.flip()        # update screen

screen = pygame.display.set_mode(size) # Set screen name and creates window
pygame.display.set_caption("Game of Crowns")

try:
    gameWorld("designlevel.txt")    # This starts the game

except: #exception handling
    pass